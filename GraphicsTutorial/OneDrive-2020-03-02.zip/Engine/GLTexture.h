#pragma once //both files include GLTexutre, pragma fixa to
#include<include/GL/glew.h>
class GLTexture
{
public:
	struct {
		GLuint id;
		int width;
		int height;
	};

};

