#pragma once
#include<string>
//#include<include/GL/glew.h>
#include<include/SDL.h>
extern void fatalError(std::string errorString);