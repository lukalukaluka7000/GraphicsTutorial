#include "Camera2D.h"



Camera2D::Camera2D()
{
}


Camera2D::~Camera2D()
{
}
